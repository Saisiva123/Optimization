/*

[OPT-9761] PS: UK: Non-brand Reading Landing Page Layout Test V2 - AB Test - QA

[OPT-9761] Control
[OPT-9761] Ch1 New Layout

https://uk.norton.com/ps/4up_norton360_nav_ns_nd_np_Reading_tw_nb.html

*/

<style id="tntStyle">body{display:none !important}</style>
<style>
.tnt_compare {
    color: #0089c6;
}
.tnt_compare a {
    text-decoration: underline;
}

</style>

<script type="text/javascript">
$().ready(function() {
    try {

        // [OPT-9761] Ch1

        $('.hero-para-wrapper:eq(0) .panel-wrapper').replaceWith('<div class="panel-wrapper padding-left-10x"> <div class="title"> <div class="rebrand-title"> <div></div> <h1 class="rebrand-header yellow-1">Norton AntiVirus Plus</h1> </div> </div> <div class="rich-text-editor parbase"> <h3> Powerful protection for your device and the personal information it stores </h3> </div> <div class="panel"> <div class="panel-container bordertop-0x background-"> <div class="panel-wrapper"> <div class="parbase product-data-display"> <div class="pdd-dark-background"> <div> <div class="pdd-hero-transactions"> <div class="pdd-transactions"> <ul class="pdd-subscriptions pdd-standard-tab"> <li class="pdd-subscription pdd-standard-entitlement pdd-subscription-1 pdd-subscription-selected" data-ent="entitlement1" > 1 Year </li> <li class="pdd-subscription pdd-standard-entitlement pdd-subscription-2" data-ent="entitlement2" > 2 Years </li> </ul> <div class="pdd-prices" data-ent="entitlement1"> <div class="pdd-transaction-prices"> <div class="pdd-prices-old-price">£ 89.99</div> <div class="pdd-prices-current-price">£ 39.99</div> <div class="pdd-prices-savings-container"> <div class="pdd-prices-savings">55% OFF*</div> </div> <div class="pdd-secondary-price-format"></div> </div> <div class="pdd-transactions-button"> <a data-link-type="buy-now" class="btn-default pdd-btn font-3xl" href="https://buy.norton.com/ps?selSKU=21385347&ctry=GB&lang=en&tppc=B447382B-03F2-C6A2-E019-BECCCC5FAA00&ptype=cart&trf_id=nortoncom&inid=hho_nortoncom_store_4up_norton360_nav_ns_nd_np_Reading_tw_nb_pdpage&promocode=DEFAULTWEB" >Subscribe Now</a ><span class="tnt_compare" >&nbsp; Compare New Norton Plans <a href="#planschart">Here</a></span > </div> <div class="pdd-prices-entitlement-note"> <p> Price shown is for first year.<br /> Then £ 89.99/year.<br /> See subscription details below.* </p> </div> <div class="pdd-prices-entitlement-note-devices"> Norton 360 Premium offers protection for up to 10 PCs, Mac®, smartphones or tablets </div> </div> <div class="pdd-prices" data-ent="entitlement1"> <div class="pdd-transaction-prices"> <div class="pdd-prices-old-price">£ 89.99</div> <div class="pdd-prices-current-price">£ 99.99</div> <div class="pdd-prices-savings-container"> <div class="pdd-prices-savings">55% OFF*</div> </div> <div class="pdd-secondary-price-format"></div> </div> <div class="pdd-transactions-button"> <a data-link-type="buy-now" class="btn-default pdd-btn font-3xl" href="https://buy.norton.com/ps?selSKU=21392953&amp;ctry=GB&amp;lang=en&amp;tppc=B447382B-03F2-C6A2-E019-BECCCC5FAA00&amp;ptype=cart&amp;trf_id=nortoncom&amp;multipage=true&amp;inid=hho_nortoncom_store_premium_pdpage&amp;promocode=DEFAULTWEB" >Subscribe Now</a > <span class="tnt_compare" >&nbsp; Compare New Norton Plans <a href="#planschart">Here</a></span > </div> <div class="pdd-prices-entitlement-note"> <p> Price shown is for first two years.<br /> Then £ 89.99/year.<br /> See subscription details below.* </p> </div> <div class="pdd-prices-entitlement-note-devices"> Norton 360 Premium offers protection for up to 10 PCs, Mac®, smartphones or tablets </div> </div> </div> </div> </div> </div> </div> <div class="parbase responsive-image"> <picture> <source srcset=" //now.symassets.com/content/dam/norton/global/images/non-product/icons/icon_win_win_20_compatible_android_mac_ios_en_135x26.png " media="(min-width: 992px)" /> <source srcset=" //now.symassets.com/content/dam/norton/global/images/non-product/icons/icon_win_win_20_compatible_android_mac_ios_en_135x26.png " media="(min-width: 768px)" /> <img class="img-responsive margin-top-4x image-76f74c27eb994dfb95dc742ec489fb2a" src="//now.symassets.com/content/dam/norton/global/images/non-product/icons/icon_win_win_20_compatible_android_mac_ios_en_135x26.png" /> </picture> </div> </div> </div> </div> </div>');
        
        $(".pdd-prices").eq(1).hide();

        $(".pdd-subscription") .eq(0) .addClass("pdd-subscription-selected")

        $(".pdd-subscription-1,.pdd-subscription-2").click(function () { $(".pdd-prices").hide().eq($(this).index()).show(); $(".pdd-subscription") .eq($(this).index()) .addClass("pdd-subscription-selected").siblings() .removeClass("pdd-subscription-selected"); });
    
        // $('.page-content > .section:eq(2)').after($('.page-content > .section:eq(1)'));

        // $('.page-content > .section:eq(0)').after($('.page-content > .section:eq(3)'));
      
    }
     catch (err) {
        console.log('ERROR:' + err.toString());
    }
    //$('#tntStyle').remove();
});
</script>
